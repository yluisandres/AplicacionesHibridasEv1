var arroperadores
var arrvalores
var valoractual   
function obtenerNumero(evt)
{
    //alert (evt.target.id)    
    var valorClick=evaluarTeclado(evt.target.id)
    var display=document.getElementById("display")
    //obtenemos el valor actual del display
    var valoractual=display.textContent;    
    //calculamos cuando se presiona =
    if(valorClick=="=")
    {
        calcular()
        valorClick=""
    }    
    //evaluamos si el valor es 0 se elimina el 0 y se escribe el nuevo valor
    if(valoractual==0)
    {
        //enceramos el display
        display.textContent="";        
        //asignamos el nuevo valor
        document.getElementById("display").innerHTML=valorClick;
    }
    else
    {        
        //asignamos el valor actual concatenado al valor nuevo
        document.getElementById("display").innerHTML=valoractual+""+valorClick;
    }
}

function obtenerTecla(event)
{
    //obtenemos el valor de la tecla presionada
    var tecla = event.which || event.keycode;
    var valor=String.fromCharCode(tecla)
    //evaluamos los valores ingresados por teclado que sean solo numeros y operadores
    if(evaluarValor(valor))
    {    
        //obtenemos el objeto que contiene el display
        var display=document.getElementById("display")
        //obteneos el valor actual del display
        var valoractual=display.textContent;
        //evaluamos si el valor es 0 se elimina el 0 y se escribe el nuevo valor
        if(valoractual==0)
        {
            //enceramos el display
            display.textContent="";        
            //asignamos el nuevo valor
            document.getElementById("display").innerHTML=valor;
        }
        else
        {        
            //asignamos el valor actual concatenado al valor nuevo
            document.getElementById("display").innerHTML=valoractual+""+valor;
        }
    }
}

function evaluarValor(teclaPresionada)
{
    if(teclaPresionada>= 0 || teclaPresionada == "+" || teclaPresionada == "-" || teclaPresionada == "*"  
        || teclaPresionada == "/" || teclaPresionada == "=" || teclaPresionada == ".")
    {
        return true;
    }
        return false;
}
function evaluarTeclado(valorMouse)
{
    if(valorMouse == "dividido")
    {
        valorMouse="/"
        return valorMouse
    }
    if(valorMouse == "por")
    {
        valorMouse="*"
        return valorMouse
    }
    if(valorMouse == "menos")
    {
        valorMouse="-"
        return valorMouse
    }
    if(valorMouse == "mas")
    {
        valorMouse="+"
        return valorMouse
    }
    if(valorMouse == "igual")
    {
        valorMouse="="
        return valorMouse
    }
    if(valorMouse == "punto")
    {
        valorMouse="."
        return valorMouse
    }
    return valorMouse;
}
function calcular()
{
    //asignamos el elemento display a una variable
    var pantalla=document.getElementById("display")
    //obtenemos el texto del display
    var cadena=pantalla.textContent;
    //obtenemos los caracteres
    var charcadena= cadena.split("")
    //definimos una variable donde se almacenaran los valores
    var operadores="";
    //este ciclo almacena los operadores de la cadena
    for(var i=0;i<charcadena.length;i++)
    {
        if(charcadena[i]=='+'||charcadena[i]=='-'||charcadena[i]=='*'||charcadena[i]=='/')
        {
            operadores=operadores+charcadena[i]+','
        }
    }    
    //Dividimos la cadena  para obtener solo los números divididos por cualquier operador
    var arrcadena=cadena.split('+').join(',').split('-').join(',').split('*').join(',').split('/').join(',')
    //obtenemos los operadores y lo guardamos en el arreglo arroperadore
    arroperadores=operadores.split(",")
    //obtenemos los números y lo guardamos en el arreglo arrvalores
    arrvalores=arrcadena.split(',')
    //
    sustraccion()
    //producto()
    //division()    
    //suma()
    //resta()
    
         
}
function reducirarreglosval()
{
    alert ("Dentro de la función ")
    var contadored=0
    var newarr
    
    while(contadored<arrvalores.length)            
    {
        if(arrvalores[contadored]!="")
        {
            newarr=newarr+arrvalores[contadored]+","
        }
        contadored++                         
    }
    arrvalores=newarr.split(",")
    
}
function reducirarreglosop()
{
    alert ("Dentro de la función ")
    var contadored=0
    var newarr=""
    while(contadored<arroperadores.length)            
    {
        if(arroperadores[contadored]!="")
        {
            newarr=newarr+arroperadores[contadored]+","
        }
        contadored++                         
    }
    arroperadores=newarr.split(",")   
}
function sustraccion()
{
    alert ("hola mundo")
    /*alert("Dentro de la Resta")
    for(var j=0;j<arroperadores.length;j++)
    {           
        if(arroperadores[j]=='-')        
        {   
            valoractual=parseFloat(arrvalores[j])+parseFloat(arrvalores[j+1])
            arrvalores[j]=valoractual
            arroperadores[j]=""
            arrvalores[j+1]=""    
            reducirarreglosop()
            reducirarreglosval()                        
            i=0
            alert("Valores "+arrvalores)
            alert("Operadores "+arroperadores)            
        }        
    }   
    */
}
function suma()
{
    for(var i=0;i<arroperadores.length;i++)
    {           
        if(arroperadores[i]=="+")        
        {   
            valoractual=parseFloat(arrvalores[i])+parseFloat(arrvalores[i+1])
            arrvalores[i]=valoractual
            arroperadores[i]=""
            arrvalores[i+1]=""    
            reducirarreglosop()
            reducirarreglosval()            
            i=0
            alert("Valores "+arrvalores)
            alert("Operadores "+arroperadores)            
        }               
    }      
}
function producto()
{
    for(var i=0;i<arroperadores.length;i++)
    {           
        if(arroperadores[i]=="*")        
        {   
            valoractual=arrvalores[i]*arrvalores[i+1]
            arrvalores[i]=valoractual
            arroperadores[i]=""
            arrvalores[i+1]=""              
            reducirarreglosop()
            reducirarreglosval()            
            i=0
            alert("Valores "+arrvalores)
            alert("Operadores "+arroperadores)            
        }        
    }    
}
function division()
{
    for(var i=0;i<arroperadores.length;i++)
    {           
        if(arroperadores[i]=="/")        
        {   
            valoractual=arrvalores[i]/arrvalores[i+1]
            arrvalores[i]=valoractual
            arroperadores[i]=""
            arrvalores[i+1]=""               
            reducirarreglosop()
            reducirarreglosval()            
            i=0
            alert("Valores "+arrvalores)
            alert("Operadores "+arroperadores)            
        }        
    }   
}
    

document.onkeypress=obtenerTecla
document.getElementsByClassName("teclado")[0].addEventListener('click', obtenerNumero, false);




    
