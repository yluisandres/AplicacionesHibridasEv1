

var Calculadora = 
{
    "arroperadores":[],
    "arrvalores":[],
    "valoractual":"",
    "contpunto":0,
    "contsigno":0,

    //Cambia el tamaño del boton que este presionado
    cambiarTamaño: function(evt)
    {
        var idboton=document.getElementById(evt.target.id).id        
        document.getElementById(idboton).style.width="18%"
        if(idboton=="mas")
        {
            document.getElementById(idboton).style.width="70%"
        }    
    },    
    volverTamaño: function(evt)
    {
        var idboton=document.getElementById(evt.target.id).id
        document.getElementById(idboton).style.width="auto"    
    },
    obtenerNumero: function(evt)
    {           
        var valorClick=Calculadora.evaluarTeclado(evt.target.id)        
        var display=document.getElementById("display")
        //obtenemos el valor actual del display        
        var valoractual=display.textContent;    
        //calculamos cuando se presiona =        
        if(valorClick=="=")
        {
            Calculadora.calcular()
            valoractual=arrvalores[0]
            valorClick=""
        }    
        if(valorClick==".")
        {          
            if(Calculadora.contpunto==0)   
            {            
                valorClick="."
                Calculadora.contpunto=1
            }
            else
            {
                valorClick=""
            }        
        }    
        if(valorClick=="on")
        {        
            valoractual=""
            valorClick="0"       
        }   
        //evaluamos si el valor es 0 se elimina el 0 y se escribe el nuevo valor
        
        if(valoractual==0)
        {
            //enceramos el display
            display.textContent="";        
            //asignamos el nuevo valor
            if(valorClick!="mm")
            {
                document.getElementById("display").innerHTML=valorClick;
            }            
            else
            {
                document.getElementById("display").innerHTML="0";
            }
        }
        else
        {        
            if(valorClick=="mm")
            {
                if(Calculadora.contsigno==0)
                {
                    document.getElementById("display").innerHTML="-"+valoractual;  
                    Calculadora.contsigno=1          
                }
                else
                {
                    var cadenaactual=valoractual.split("")
                    var nuevacadena=""
                    for(var i=0;i<cadenaactual.length;i++)
                    {
                        if(cadenaactual[i]!="-")
                        {
                            nuevacadena=nuevacadena+""+cadenaactual[i]
                        }
                    }
                    document.getElementById("display").innerHTML=nuevacadena;  
                    Calculadora.contsigno=0          
                }                
            }
            else
            {
                document.getElementById("display").innerHTML=valoractual+""+valorClick; 
            }    
            

            //asignamos el valor actual concatenado al valor nuevo
                   
            
        }
    },
    obtenerTecla:function(event)
    {
        //obtenemos el valor de la tecla presionada
        var tecla = event.which || event.keycode;
        var valor=String.fromCharCode(tecla)
        //evaluamos los valores ingresados por teclado que sean solo numeros y operadores
        if(Calculadora.evaluarValor(valor))
        {    
            //obtenemos el objeto que contiene el display
            var display=document.getElementById("display")
            //obteneos el valor actual del display
            var valoractual=display.textContent;
            //evaluamos si el valor es 0 se elimina el 0 y se escribe el nuevo valor
            if(valoractual==0)
            {
                //enceramos el display
                display.textContent="";        
                //asignamos el nuevo valor
                document.getElementById("display").innerHTML=valor;
            }
            else
            {        
                //asignamos el valor actual concatenado al valor nuevo
                document.getElementById("display").innerHTML=valoractual+""+valor;
                if(valor == "+" ||  valor == "-" || valor == "*"  
                || valor == "/" || valor == "=" || valor == "on")
                {
                    Calculadora.contpunto=0
                }
            }
        }
    },
    evaluarValor: function(teclaPresionada)
    {
        if(teclaPresionada==".")
        {          
            if(Calculadora.contpunto==0)   
            {            
                Calculadora.contpunto=1
                return true
            }
            else
            {
                return false
            }        
        }    
        if(teclaPresionada>= 0 || teclaPresionada == "+" || teclaPresionada == "-" || teclaPresionada == "*"  
        || teclaPresionada == "/" || teclaPresionada == "=" || teclaPresionada == ".")
        {
            return true;
        }
        return false;    
    },
    evaluarTeclado: function(valorMouse)
    {
        if(valorMouse == "sign")
        {
            valorMouse="mm"            
            return valorMouse
        }
        if(valorMouse == "dividido")
        {
            valorMouse="/"
            Calculadora.contpunto=0
            return valorMouse
        }
        if(valorMouse == "por")
        {
            valorMouse="*"
            Calculadora.contpunto=0
            return valorMouse
        }
        if(valorMouse == "menos")
        {
            valorMouse="-"
            Calculadora.contpunto=0
            return valorMouse
        }
        if(valorMouse == "mas")
        {
            valorMouse="+"
            Calculadora.contpunto=0
            return valorMouse
        }
        if(valorMouse == "igual")
        {
            valorMouse="="
            Calculadora.contpunto=0
            return valorMouse
        }
        if(valorMouse == "punto")
        {
            valorMouse="."
            return valorMouse
        }
        if(valorMouse == "on")
        {
            valorMouse="on"
            Calculadora.contpunto=0
            return valorMouse
        }
    
        return valorMouse;
    },

    calcular: function()
    {
        //asignamos el elemento display a una variable
        var pantalla=document.getElementById("display")
        //obtenemos el texto del display
        var cadena=pantalla.textContent;
        //obtenemos los caracteres
        var charcadena= cadena.split("")
        //definimos una variable donde se almacenaran los valores
        var operadores="";
        //este ciclo almacena los operadores de la cadena
        for(var i=0;i<charcadena.length;i++)
        {
            if(charcadena[i]=='+'||charcadena[i]=='-'||charcadena[i]=='*'||charcadena[i]=='/')
            {
                operadores=operadores+charcadena[i]+','
            }
        }    
        //Dividimos la cadena  para obtener solo los números divididos por cualquier operador
        var arrcadena=cadena.split('+').join(',').split('-').join(',').split('*').join(',').split('/').join(',')
        //obtenemos los operadores y lo guardamos en el arreglo arroperadore
        arroperadores=operadores.split(",")
        //obtenemos los números y lo guardamos en el arreglo arrvalores
        arrvalores=arrcadena.split(',')    
        //llamamos a las funciones por jerarquía de operaciones
        Calculadora.producto()
        Calculadora.division()    
        Calculadora.suma()
        Calculadora.sustraccion()            
    },
    sustraccion: function()
    {       
        for(var j=0;j<arroperadores.length;j++)
        {           
            if(arroperadores[j]=='-')        
            {   
                valoractual=parseFloat(arrvalores[j])-parseFloat(arrvalores[j+1])
                arrvalores[j]=valoractual
                arroperadores[j]=""
                arrvalores[j+1]="" 
                Calculadora.reducirarreglos()    
                j=0               
            }           
        }       
    },
    suma: function()
    {
        for(var i=0;i<arroperadores.length;i++)
        {           
            if(arroperadores[i]=="+")        
            {   
                valoractual=parseFloat(arrvalores[i])+parseFloat(arrvalores[i+1])
                arrvalores[i]=valoractual
                arroperadores[i]=""
                arrvalores[i+1]=""                                                
                Calculadora.reducirarreglos()    
                i=0                       
            }               
        }      
    },
    producto: function()
    {
        for(var i=0;i<arroperadores.length;i++)
        {           
            if(arroperadores[i]=="*")        
            {   
                valoractual=arrvalores[i]*arrvalores[i+1]
                arrvalores[i]=valoractual
                arroperadores[i]=""
                arrvalores[i+1]=""                                      
                Calculadora.reducirarreglos()    
                i=0                                           
            }        
        }    
    },
    division: function()
    {
        for(var i=0;i<arroperadores.length;i++)
        {           
            if(arroperadores[i]=="/")        
            {   
                valoractual=arrvalores[i]/arrvalores[i+1]
                arrvalores[i]=valoractual
                arroperadores[i]=""
                arrvalores[i+1]=""                                                        
                Calculadora.reducirarreglos() 
                i=0                                    
            }        
        }   
    },
    reducirarreglos: function()
    {    
        var contadored=0
        var newarr=""    
        while(contadored<arrvalores.length)            
        {
            if(arrvalores[contadored]!="")
            {
                newarr=newarr+arrvalores[contadored]+","
            }
            contadored++                         
        }
        arrvalores=newarr.split(",")
        newarr=""
        contadored=0
        while(contadored<arroperadores.length)            
        {
            if(arroperadores[contadored]!="")
            {
                newarr=newarr+arroperadores[contadored]+","
            }
            contadored++                         
        }
        arroperadores=newarr.split(",")  
        newarr=""    
    }    
}



document.onkeypress=Calculadora.obtenerTecla
document.getElementsByClassName("teclado")[0].addEventListener('click', Calculadora.obtenerNumero, false);
document.getElementsByClassName("teclado")[0].addEventListener('mousedown', Calculadora.cambiarTamaño, false);
document.getElementsByClassName("teclado")[0].addEventListener('mouseup', Calculadora.volverTamaño, false);




    
