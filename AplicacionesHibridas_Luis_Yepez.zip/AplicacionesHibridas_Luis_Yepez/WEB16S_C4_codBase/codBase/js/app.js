var arroperadores
var arrvalores
var valoractual   
var contpunto=0
function cambiarTamaño(evt)
{    
    var idboton=document.getElementById(evt.target.id).id
    var ancho=document.getElementById(idboton).style.width
    var alto=document.getElementById(idboton).style.height
    
    document.getElementById(idboton).style.width="18%"
    if(idboton=="mas")
    {
        document.getElementById(idboton).style.width="70%"
    }
    
}
function volverTamaño(evt)
{    
    var idboton=document.getElementById(evt.target.id).id
    document.getElementById(idboton).style.width="auto"
     
}
function obtenerNumero(evt)
{
    //alert (evt.target.id)    
    var valorClick=evaluarTeclado(evt.target.id)
    var display=document.getElementById("display")
    //obtenemos el valor actual del display
    var valoractual=display.textContent;    
    //calculamos cuando se presiona =
    if(valorClick=="=")
    {
        calcular()
        valoractual=Math.trunc(arrvalores[0],4)
        valorClick=""
    }    
    if(valorClick==".")
    {          
        if(contpunto==0)   
        {            
            valorClick="."
            contpunto=1
        }
        else
        {
            valorClick=""
        }        
    }    
    if(valorClick=="on")
    {        
        valoractual=""
        valorClick="0"       
    }   
    //evaluamos si el valor es 0 se elimina el 0 y se escribe el nuevo valor
    if(valoractual==0)
    {
        //enceramos el display
        display.textContent="";        
        //asignamos el nuevo valor
        document.getElementById("display").innerHTML=valorClick;
    }
    else
    {        
        //asignamos el valor actual concatenado al valor nuevo
        document.getElementById("display").innerHTML=valoractual+""+valorClick;
    }
}

function obtenerTecla(event)
{
    //obtenemos el valor de la tecla presionada
    var tecla = event.which || event.keycode;
    var valor=String.fromCharCode(tecla)
    //evaluamos los valores ingresados por teclado que sean solo numeros y operadores
    if(evaluarValor(valor))
    {    
        //obtenemos el objeto que contiene el display
        var display=document.getElementById("display")
        //obteneos el valor actual del display
        var valoractual=display.textContent;
        //evaluamos si el valor es 0 se elimina el 0 y se escribe el nuevo valor
        if(valoractual==0)
        {
            //enceramos el display
            display.textContent="";        
            //asignamos el nuevo valor
            document.getElementById("display").innerHTML=valor;
        }
        else
        {        
            //asignamos el valor actual concatenado al valor nuevo
            document.getElementById("display").innerHTML=valoractual+""+valor;
        }
    }
}

function evaluarValor(teclaPresionada)
{
    if(teclaPresionada>= 0 || teclaPresionada == "+" || teclaPresionada == "-" || teclaPresionada == "*"  
        || teclaPresionada == "/" || teclaPresionada == "=" || teclaPresionada == ".")
    {
        return true;
    }
        return false;
}
function evaluarTeclado(valorMouse)
{
    if(valorMouse == "dividido")
    {
        valorMouse="/"
        contpunto=0
        return valorMouse
    }
    if(valorMouse == "por")
    {
        valorMouse="*"
        contpunto=0
        return valorMouse
    }
    if(valorMouse == "menos")
    {
        valorMouse="-"
        contpunto=0
        return valorMouse
    }
    if(valorMouse == "mas")
    {
        valorMouse="+"
        contpunto=0
        return valorMouse
    }
    if(valorMouse == "igual")
    {
        valorMouse="="
        contpunto=0
        return valorMouse
    }
    if(valorMouse == "punto")
    {
        valorMouse="."
        return valorMouse
    }
    if(valorMouse == "on")
    {
        valorMouse="on"
        contpunto=0
        return valorMouse
    }
    
    return valorMouse;
}
function calcular()
{
    //asignamos el elemento display a una variable
    var pantalla=document.getElementById("display")
    //obtenemos el texto del display
    var cadena=pantalla.textContent;
    //obtenemos los caracteres
    var charcadena= cadena.split("")
    //definimos una variable donde se almacenaran los valores
    var operadores="";
    //este ciclo almacena los operadores de la cadena
    for(var i=0;i<charcadena.length;i++)
    {
        if(charcadena[i]=='+'||charcadena[i]=='-'||charcadena[i]=='*'||charcadena[i]=='/')
        {
            operadores=operadores+charcadena[i]+','
        }
    }    
    //Dividimos la cadena  para obtener solo los números divididos por cualquier operador
    var arrcadena=cadena.split('+').join(',').split('-').join(',').split('*').join(',').split('/').join(',')
    //obtenemos los operadores y lo guardamos en el arreglo arroperadore
    arroperadores=operadores.split(",")
    //obtenemos los números y lo guardamos en el arreglo arrvalores
    arrvalores=arrcadena.split(',')    
    //llamamos a las funciones por jerarquía de operaciones
    producto()
    division()    
    suma()
    sustraccion()            
}

function sustraccion()
{   
    for(var j=0;j<arroperadores.length;j++)
    {           
        if(arroperadores[j]=='-')        
        {   
            valoractual=parseFloat(arrvalores[j])-parseFloat(arrvalores[j+1])
            arrvalores[j]=valoractual
            arroperadores[j]=""
            arrvalores[j+1]="" 
            reducirarreglos()    
            j=0               
        }        
    }       
}
function suma()
{
    for(var i=0;i<arroperadores.length;i++)
    {           
        if(arroperadores[i]=="+")        
        {   
            valoractual=parseFloat(arrvalores[i])+parseFloat(arrvalores[i+1])
            arrvalores[i]=valoractual
            arroperadores[i]=""
            arrvalores[i+1]=""                                                
            reducirarreglos()    
            i=0                       
        }               
    }      
}
function producto()
{
    for(var i=0;i<arroperadores.length;i++)
    {           
        if(arroperadores[i]=="*")        
        {   
            valoractual=arrvalores[i]*arrvalores[i+1]
            arrvalores[i]=valoractual
            arroperadores[i]=""
            arrvalores[i+1]=""                                      
            reducirarreglos()    
            i=0                                           
        }        
    }    
}
function division()
{
    for(var i=0;i<arroperadores.length;i++)
    {           
        if(arroperadores[i]=="/")        
        {   
            valoractual=arrvalores[i]/arrvalores[i+1]
            arrvalores[i]=valoractual
            arroperadores[i]=""
            arrvalores[i+1]=""                                                        
            reducirarreglos() 
            i=0                                    
        }        
    }   
}
function reducirarreglos()
{    
    var contadored=0
    var newarr=""
    
    while(contadored<arrvalores.length)            
    {
        if(arrvalores[contadored]!="")
        {
            newarr=newarr+arrvalores[contadored]+","
        }
        contadored++                         
    }
    arrvalores=newarr.split(",")
    newarr=""
    contadored=0
    while(contadored<arroperadores.length)            
    {
        if(arroperadores[contadored]!="")
        {
            newarr=newarr+arroperadores[contadored]+","
        }
        contadored++                         
    }
    arroperadores=newarr.split(",")  
    newarr=""
    
}    

document.onkeypress=obtenerTecla
document.getElementsByClassName("teclado")[0].addEventListener('click', obtenerNumero, false);
document.getElementsByClassName("teclado")[0].addEventListener('mousedown', cambiarTamaño, false);
document.getElementsByClassName("teclado")[0].addEventListener('mouseup', volverTamaño, false);




    
